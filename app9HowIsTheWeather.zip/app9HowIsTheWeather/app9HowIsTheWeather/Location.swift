//
//  Location.swift
//  app9HowIsTheWeather
//
//  Created by Ojus Kapoor on 18/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import CoreLocation

class Location {
    static var sharedInstance = Location()
    private init() {}
    var logitude: Double!
    var latitude: Double!
}
