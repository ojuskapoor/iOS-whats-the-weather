//
//  constants.swift
//  app9HowIsTheWeather
//
//  Created by Ojus Kapoor on 17/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import Foundation

let base_url = ""
let latitude = ""
let longitude = ""
let app_id = ""
let api_key = ""

typealias downloadComplete = () -> ()

let current_Weather_Url = "http://api.openweathermap.org/data/2.5/weather?lat=\(Location.sharedInstance.latitude!)&lon=\(Location.sharedInstance.logitude!)&appid=cf82ef4dc57745bd0bf57f504e4e637c"

let forecast_URL = "http://api.openweathermap.org/data/2.5/forecast/daily?lat=\(Location.sharedInstance.latitude!)&lon=\(Location.sharedInstance.logitude!)&cnt=10&appid=cf82ef4dc57745bd0bf57f504e4e637c"

