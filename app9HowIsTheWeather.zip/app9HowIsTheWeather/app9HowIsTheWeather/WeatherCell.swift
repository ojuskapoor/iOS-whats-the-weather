//
//  WeatherCell.swift
//  app9HowIsTheWeather
//
//  Created by Ojus Kapoor on 18/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import UIKit

class WeatherCell: UITableViewCell {

    @IBOutlet weak var weatherIcon: UIImageView!
    
    @IBOutlet weak var dayLbl: UILabel!
    
    @IBOutlet weak var weatherType: UILabel!
    
    @IBOutlet weak var lowTemp: UILabel!
    
    @IBOutlet weak var highTemp: UILabel!
    
    
    func configureCell(forecast: Forecast) {
        
        lowTemp.text = "Low: \(forecast.lowTemp)°"
        highTemp.text = "High: \(forecast.highTemp)°"
        weatherType.text = forecast.weatherType
        dayLbl.text = forecast.date
        weatherIcon.image = UIImage(named: forecast.weatherType)
        
    }
    
    
}
